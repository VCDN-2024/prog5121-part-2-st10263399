
package progpoe2024;

public class Login {
    
    //the username enetered by the user is checked to see if it is less than 5 characters and contains an underscore
    public boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[^a-zA-Z0-9].*");
    }
    
    public String registerUser(String user, String password) {
        //if the username and password entered meets the requirements, then a message is displayed to the user that it was successfully captured, otherwise an error message appears
        if (user.length()<=5 && user.contains("_") && checkPasswordComplexity(password)) {
            return "Username and Password successfullfy captured";
        } else{
            return "Username and password is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        
    }
    
    public boolean loginUser(String user, String enteredUsername, String enteredPassword, String Password) {
        return enteredUsername.equals(user) && enteredPassword.equals(Password);
    }
    
    public String returnLoginStatus(boolean isSuccessful, String firstName, String LastName) {
        if (isSuccessful) {
            return "Welcome " + firstName + ", " + LastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

