package progpoe2024;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PROGPOE2024 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Create variables to receive user input
        System.out.println("Welcome to Registration and Login System");
        System.out.println("----------------------------------------");

        System.out.println("Enter your username: ");
        String username = scanner.nextLine();

        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();

        Login login = new Login();

        String registrationMessage = login.registerUser(username, password);
        System.out.println(registrationMessage);

        if (registrationMessage.equals("User registered successfully.")) {
            System.out.println("Enter your username to login: ");
            String enteredUsername = scanner.nextLine();

            System.out.println("Enter your password to login: ");
            String enteredPassword = scanner.nextLine();

            boolean isSuccessful = login.loginUser(username, enteredUsername, enteredPassword, password);
            System.out.println(login.returnLoginStatus(isSuccessful, firstName, lastName));

            if (isSuccessful) {
                System.out.println("Welcome to EasyKanban");

                AddTask taskManager = new AddTask();
                while (true) {
                    String[] options = {"Add Tasks", "Show Report", "Quit"};
                    int choice = JOptionPane.showOptionDialog(null, "Choose an option", "Task Manager",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                    switch (choice) {
                        case 0:
                            taskManager.addTasks();
                            break;
                        case 1:
                            taskManager.showReport();
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, "Exiting application.");
                            System.exit(0);
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid choice, please select from the menu.");
                    }
                }
            }
        }

        scanner.close();
    }

    
}

