package progpoe2024;

import javax.swing.JOptionPane;
import java.util.ArrayList;

class Task {
    int taskNumber;
    String taskName;
    String description;
    String developerName;
    String taskDuration;
    String taskStatus;
    String status;

    public Task(int taskNumber, String taskName, String description, String developerName, String taskDuration, String taskStatus, String status) {
        this.taskNumber = taskNumber;
        this.taskName = taskName;
        this.description = description;
        this.developerName = developerName;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.status = status;
    }

    public String printTaskDetails() {
        return "Task Status: " + status + "\n" +
               "Developer Details: " + developerName + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + description + "\n" +
               "Task ID: " + taskStatus + "\n" +
               "Task Duration: " + taskDuration + "\n";
    }
}

public class AddTask {
    
    private static final ArrayList<Task> tasks = new ArrayList<>();
    
    private static void showMenu() {
        System.out.println("\nMenu:");
        System.out.println("1) Add Tasks");
        System.out.println("2) Show Report");
        System.out.println("3) Quit");
        System.out.print("Choose an option: ");
    }

    private static void addTasks() {
        String numTasksStr = JOptionPane.showInputDialog("How many tasks do you wish to enter?");
        int numTasks;
        try {
            numTasks = Integer.parseInt(numTasksStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number, please enter an integer.");
            return;
        }

        for (int taskNum = 0; taskNum < numTasks; taskNum++) {
            String taskName = JOptionPane.showInputDialog("Enter name for task " + taskNum + ": ");

            String description;
            while (true) {
                description = JOptionPane.showInputDialog("Enter description (max 50 characters): ");
                if (description.length() <= 50) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Description exceeds 50 characters, please try again.");
                }
            }

            String developerName = JOptionPane.showInputDialog("Enter developer's full name: ");

            String taskDuration = JOptionPane.showInputDialog("Enter task duration: ");

            String taskStatus = (taskName.length() >= 2 ? taskName.substring(0, 2) : taskName) + ":" + taskNum + ":" + 
                                (developerName.length() >= 3 ? developerName.substring(developerName.length() - 3) : developerName);
            taskStatus = taskStatus.toUpperCase();

            String[] statusOptions = {"to do", "done", "doing"};
            String status;
            while (true) {
                status = (String) JOptionPane.showInputDialog(null, "Select task status", "Task Status",
                        JOptionPane.QUESTION_MESSAGE, null, statusOptions, statusOptions[0]);
                if (status != null && (status.equals("to do") || status.equals("done") || status.equals("doing"))) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid status, please enter 'to do', 'done', or 'doing'.");
                }
            }

            Task task = new Task(taskNum, taskName, description, developerName, taskDuration, taskStatus, status);
            tasks.add(task);
            JOptionPane.showMessageDialog(null, "Task added successfully!\n\n" + task.toString());
        }
    }
    
    private static boolean checkTaskDescription(String description) {
        return description.length() <= 50;
    }

    private static String createTaskID(String taskName, int taskNum, String developerName) {
        return (taskName.length() >= 2 ? taskName.substring(0, 2) : taskName) + ":" + taskNum + ":" + 
               (developerName.length() >= 3 ? developerName.substring(developerName.length() - 3) : developerName).toUpperCase();
    }

    private static void showReport() {
        JOptionPane.showMessageDialog(null, "Coming soon...");
    }
    
    private static int returnTotalHours() {
        int totalHours = 0;
        for (Task task : tasks) {
            try {
                totalHours += Integer.parseInt(task.taskDuration);
            } catch (NumberFormatException e) {
                System.out.println("Invalid task duration for task " + task.taskNumber);
            }
        }
        return totalHours;
    }
    
}
