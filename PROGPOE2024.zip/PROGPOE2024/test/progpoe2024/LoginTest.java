/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progpoe2024;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 *
 * @author lab_services_student
 */
public class LoginTest {
    
    public LoginTest() {
    }

    Login test = new Login();

    @Test
    public void testCheckUserName() {
        boolean check = test.checkUsername("kyl_1");
        assertTrue(check);
    }
    
    @Test
    public void testCheckUserNameFormat() {
        boolean check = test.checkUsername("kyle!!!!!!!");
        assertFalse(check);
    }

    @Test
    public void testCheckPasswordComplexity() {        
        boolean check = test.checkPasswordComplexity("Ch&&sec@ke99!");
        assertTrue(check);
    }

    @Test
    public void testCheckPasswordComplexityFormat() {        
        boolean check = test.checkPasswordComplexity("password");
        assertFalse(check);
    }
    
    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
